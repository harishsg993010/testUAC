#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <string>

bool RunAsAdmin(const wchar_t* appPath) {
    SHELLEXECUTEINFO shExInfo = {};
    shExInfo.cbSize = sizeof(SHELLEXECUTEINFO);
    shExInfo.fMask = SEE_MASK_NOCLOSEPROCESS;
    shExInfo.hwnd = nullptr;
    shExInfo.lpVerb = L"runas";
    shExInfo.lpFile = appPath;
    shExInfo.lpParameters = nullptr;
    shExInfo.lpDirectory = nullptr;
    shExInfo.nShow = SW_NORMAL;

    if (ShellExecuteEx(&shExInfo)) {
        WaitForSingleObject(shExInfo.hProcess, INFINITE);
        CloseHandle(shExInfo.hProcess);
        return true;
    }

    return false;
}

int main() {
    HANDLE hProcSnap;
    PROCESSENTRY32 pe32;

    hProcSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hProcSnap == INVALID_HANDLE_VALUE) {
        std::cerr << "Failed to create process snapshot." << std::endl;
        return 1;
    }

    pe32.dwSize = sizeof(PROCESSENTRY32);

    if (!Process32First(hProcSnap, &pe32)) {
        CloseHandle(hProcSnap);
        std::cerr << "Failed to retrieve the first process entry." << std::endl;
        return 1;
    }

    while (Process32Next(hProcSnap, &pe32)) {
        std::wstring username = GetProcessUserName(pe32.th32ProcessID);
        if (username.empty() || username == L"NT AUTHORITY\\SYSTEM") {
            // Run the application with elevated privileges (UAC)
            if (RunAsAdmin(L"C:\\Windows\\System32\\notepad.exe")) {
                break;
            }
        }
    }

    CloseHandle(hProcSnap);

    return 0;
}

